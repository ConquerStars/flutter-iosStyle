import 'package:flutter/material.dart';

class TabFound extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.only(left: 26, right: 26),
        child: Text('发现')
      ),
    );
  }
}